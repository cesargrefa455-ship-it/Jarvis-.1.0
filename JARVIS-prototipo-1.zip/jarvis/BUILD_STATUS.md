# Estado de compilación

- Android SDK command-line tools: instalado.
- Android SDK platform 35: instalado.
- Android build-tools 35.0.0: instalado.
- Gradle 8.9: instalado.
- AndroidX: configurado correctamente.
- Backend Python: sintaxis validada.
- APK: no generado en este sandbox.

## Bloqueo técnico

El entorno de ejecución es `aarch64/ARM64`. El plugin Android descargó `aapt2-8.7.3-12006047-linux`, que es un ejecutable `x86-64`; al ejecutarlo devuelve `Exec format error`. No hay emulador x86_64 disponible en el entorno, por lo que no es honesto afirmar que el APK fue compilado.

El mismo proyecto debe compilarse en Android Studio o CI sobre Linux x86_64, macOS o Windows con Android SDK 35. Comando:

```bash
gradle :android-app:app:assembleDebug
```
