# J.A.R.V.I.S. — prototipo funcional 1.0

Primera entrega del asistente Android nativo: UI Jetpack Compose, núcleo modular, memoria Room, TextToSpeech, control de permisos inicial y backend FastAPI con proveedor de IA configurable.

## Estado honesto

Este entorno no tiene Android SDK/Gradle ni un dispositivo Android conectado, por lo que todavía no se ha generado ni verificado un APK. La UI permite conversación local de demostración, pero el proveedor remoto debe conectarse desde la app en la siguiente iteración.

## Backend

```bash
cd backend
python3 -m venv .venv && . .venv/bin/activate
pip install -r requirements.txt
export OPENAI_API_KEY='...'
export OPENAI_MODEL='modelo-disponible-en-tu-cuenta'
uvicorn main:app --host 127.0.0.1 --port 8000
```

Antes de elegir un modelo, consultar el catálogo real del proveedor. No colocar claves en el APK.

## Android

Abrir `android-app` como proyecto Gradle en Android Studio con SDK 35 y ejecutar en un dispositivo Android 8+; después usar `./gradlew assembleDebug`. La captura, reconocimiento de voz y automatizaciones aún requieren integrar sus flujos de permisos y pruebas en el dispositivo.

## Próximas fases

1. Retrofit hacia `/ai/chat` con timeout, autenticación de sesión y manejo offline.
2. SpeechRecognizer y CameraX/ML Kit con permisos visibles.
3. Cifrado de memoria sensible mediante Android Keystore.
4. WorkManager, aprobaciones para acciones sensibles y pruebas unitarias/integración.
5. Compilación real en CI o Android Studio y generación del APK.
