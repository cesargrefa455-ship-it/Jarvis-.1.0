# J.A.R.V.I.S. — entregas

- [x] Crear estructura Android nativa y backend FastAPI.
- [x] Crear UI Compose con estados visibles y TextToSpeech.
- [x] Conectar la app con `/ai/chat` mediante Retrofit.
- [x] Añadir fallback local cuando no hay conexión.
- [x] Añadir reconocimiento de voz con permiso visible.
- [x] Guardar respuestas en memoria Room.
- [x] Crear interfaces del núcleo y guardia de acciones sensibles.
- [ ] Cifrar memoria sensible con Android Keystore.
- [ ] Integrar CameraX/ML Kit con autorización explícita y OCR.
- [ ] Integrar WorkManager y aprobaciones para automatizaciones.
- [ ] Añadir pruebas unitarias e integración.
- [ ] Compilar y probar APK en Android SDK/dispositivo real.
