package com.jarvis

interface JarvisModule { val name: String; suspend fun initialize(); suspend fun execute(input: String): String }

class PermissionGuard {
    private val sensitive = setOf("send_message", "share_data", "purchase", "delete_file", "modify_security")
    fun canExecute(action: String, approved: Boolean) = action !in sensitive || approved
}

class ModuleRegistry {
    private val modules = linkedMapOf<String, JarvisModule>()
    fun register(module: JarvisModule) { require(module.name.isNotBlank()); require(module.name !in modules); modules[module.name] = module }
    fun get(name: String) = modules[name]
    fun availableModules() = modules.keys.toList()
}

class JarvisCore(private val provider: AIProvider, private val modules: ModuleRegistry = ModuleRegistry()) {
    suspend fun process(input: String, context: String = ""): String {
        val command = input.trim()
        if (command.isBlank()) return "No he recibido ninguna instrucción, señor."
        return try { provider.generate(command, context) } catch (_: Exception) { "No puedo contactar con el servicio de IA. El modo local sigue disponible." }
    }
}

interface AIProvider { suspend fun generate(prompt: String, context: String): String }
