package com.jarvis

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import androidx.room.Room
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch

class JarvisViewModel(app: Application) : AndroidViewModel(app) {
    private val db = Room.databaseBuilder(app, JarvisDatabase::class.java, "jarvis.db").build()
    private val remote = JarvisCore(RemoteAIProvider(JarvisNetwork.api))
    private val _response = MutableStateFlow("Buenos días, señor. J.A.R.V.I.S. está operativo.")
    val response: StateFlow<String> = _response.asStateFlow()
    private val _busy = MutableStateFlow(false)
    val busy: StateFlow<Boolean> = _busy.asStateFlow()
    private val _memoryCount = MutableStateFlow(0)
    val memoryCount: StateFlow<Int> = _memoryCount.asStateFlow()
    private val _capabilities = MutableStateFlow(listOf("Conversación IA", "Memoria Room", "Voz TTS", "Reconocimiento de voz"))
    val capabilities: StateFlow<List<String>> = _capabilities.asStateFlow()

    init { refreshMemoryCount() }

    fun process(command: String) {
        if (command.isBlank() || _busy.value) return
        viewModelScope.launch {
            _busy.value = true
            val result = try { remote.process(command) } catch (_: Exception) { localFallback(command) }
            _response.value = result
            _busy.value = false
        }
    }

    fun addCapability(name: String) {
        val clean = name.trim()
        if (clean.isNotBlank() && clean !in _capabilities.value) _capabilities.value = _capabilities.value + clean
    }

    fun remember(content: String) {
        if (content.isBlank()) return
        viewModelScope.launch { db.memoryDao().save(MemoryEntity(category = "user", content = content)); refreshMemoryCount() }
    }

    private fun refreshMemoryCount() { viewModelScope.launch { _memoryCount.value = db.memoryDao().getAll().size } }
    private fun localFallback(command: String) = when {
        command.contains("estado", true) -> "Todos los módulos locales están disponibles. La conexión remota no está disponible."
        command.contains("recuerda", true) -> "Puedo guardar ese dato cuando me indiques qué debo recordar."
        else -> "He recibido su solicitud, pero el servicio remoto no está disponible. El modo local tiene capacidades limitadas."
    }
}
