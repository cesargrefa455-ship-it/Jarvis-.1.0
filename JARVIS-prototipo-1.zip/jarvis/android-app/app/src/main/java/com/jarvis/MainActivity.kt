package com.jarvis

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Bundle
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.viewModels
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import java.util.Locale

private val Navy = Color(0xFF050B14); private val Cyan = Color(0xFF53D8FB); private val Muted = Color(0xFF8FA8B8)

class MainActivity : ComponentActivity() {
    private val vm: JarvisViewModel by viewModels()
    private var tts: TextToSpeech? = null
    private var recognizer: SpeechRecognizer? = null
    private var onSpeech: ((String) -> Unit)? = null
    private val micPermission = registerForActivityResult(ActivityResultContracts.RequestPermission()) { granted -> if (granted) startListening() }

    override fun onCreate(savedInstanceState: Bundle?) { super.onCreate(savedInstanceState)
        tts = TextToSpeech(this) { if (it == TextToSpeech.SUCCESS) { tts?.language = Locale("es", "ES"); tts?.setPitch(.85f); tts?.setSpeechRate(.92f) } }
        recognizer = SpeechRecognizer.createSpeechRecognizer(this)
        recognizer?.setRecognitionListener(object : RecognitionListener {
            override fun onResults(results: Bundle?) { results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull()?.let { onSpeech?.invoke(it) } }
            override fun onError(error: Int) { onSpeech?.invoke("") }
            override fun onReadyForSpeech(p: Bundle?) {}; override fun onBeginningOfSpeech() {}; override fun onRmsChanged(r: Float) {}; override fun onBufferReceived(b: ByteArray?) {}; override fun onEndOfSpeech() {}; override fun onPartialResults(b: Bundle?) {}; override fun onEvent(t: Int, p: Bundle?) {}
        })
        setContent { JarvisApp(vm, ::speak, ::requestListening) }
    }
    private fun requestListening(callback: (String) -> Unit) { onSpeech = callback; if (ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED) startListening() else micPermission.launch(Manifest.permission.RECORD_AUDIO) }
    private fun startListening() { recognizer?.startListening(Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply { putExtra(RecognizerIntent.EXTRA_LANGUAGE, "es-ES"); putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM) }) }
    private fun speak(text: String) { tts?.speak(text, TextToSpeech.QUEUE_FLUSH, null, "jarvis_response") }
    override fun onDestroy() { recognizer?.destroy(); tts?.shutdown(); super.onDestroy() }
}

@Composable fun JarvisApp(vm: JarvisViewModel, speak: (String) -> Unit, listen: ((String) -> Unit) -> Unit) {
    val response by vm.response.collectAsState(); val busy by vm.busy.collectAsState(); val memoryCount by vm.memoryCount.collectAsState(); val capabilities by vm.capabilities.collectAsState()
    var command by remember { mutableStateOf("") }; var listening by remember { mutableStateOf(false) }; var newCapability by remember { mutableStateOf("") }; var showCapabilities by remember { mutableStateOf(false) }
    MaterialTheme(colorScheme = darkColorScheme(background = Navy, surface = Color(0xFF0B1724), primary = Cyan, onBackground = Color.White)) {
        Column(Modifier.fillMaxSize().background(Navy).padding(24.dp), horizontalAlignment = Alignment.CenterHorizontally) {
            Text("J.A.R.V.I.S.", color = Cyan, fontSize = 28.sp, fontWeight = FontWeight.Bold); Text("JUST A RATHER VERY INTELLIGENT SYSTEM", color = Muted, fontSize = 10.sp)
            Spacer(Modifier.height(30.dp)); Box(Modifier.size(190.dp).background(if (busy) Color(0xFF164E63) else Color(0xFF0D2737), CircleShape), contentAlignment = Alignment.Center) { Text(if (busy) "THINKING" else "CORE\nONLINE", color = Cyan, fontSize = 22.sp, fontWeight = FontWeight.Bold) }
            Spacer(Modifier.height(22.dp)); Text(response, color = Color.White, modifier = Modifier.fillMaxWidth()); Spacer(Modifier.height(18.dp))
            OutlinedTextField(command, { command = it }, Modifier.fillMaxWidth(), label = { Text("Escribir comando") }, singleLine = true)
            Spacer(Modifier.height(12.dp)); Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                Button({ listening = !listening; if (listening) listen { text -> if (text.isNotBlank()) command = text; listening = false } }, Modifier.weight(1f)) { Text(if (listening) "ESCUCHANDO" else "HABLAR") }
                Button({ vm.process(command); command = "" }, Modifier.weight(1f), enabled = !busy) { Text("ENVIAR") }
            }
            Spacer(Modifier.height(12.dp)); OutlinedButton({ vm.remember(response) }, Modifier.fillMaxWidth()) { Text("GUARDAR RESPUESTA EN MEMORIA") }
            Spacer(Modifier.height(22.dp)); Status("CORE", if (busy) "PROCESSING" else "READY"); Status("VOICE", "READY"); Status("MEMORY", "$memoryCount RECORDS"); Status("VISION", "AUTH REQUIRED"); Status("SECURITY", "ACTIVE")
            Spacer(Modifier.height(18.dp)); OutlinedButton({ showCapabilities = !showCapabilities }, Modifier.fillMaxWidth()) { Text(if (showCapabilities) "OCULTAR FUNCIONES" else "FUNCIONES Y MÓDULOS") }
            if (showCapabilities) {
                Spacer(Modifier.height(8.dp)); Text("Capacidades registradas", color = Cyan, modifier = Modifier.fillMaxWidth(), fontWeight = FontWeight.Bold)
                capabilities.forEach { capability -> Text("• $capability", color = Color.White, modifier = Modifier.fillMaxWidth().padding(vertical = 2.dp), fontSize = 13.sp) }
                Spacer(Modifier.height(8.dp)); OutlinedTextField(newCapability, { newCapability = it }, Modifier.fillMaxWidth(), label = { Text("Nueva función o módulo") }, singleLine = true)
                Spacer(Modifier.height(6.dp)); Button({ vm.addCapability(newCapability); newCapability = "" }, Modifier.fillMaxWidth(), enabled = newCapability.isNotBlank()) { Text("AÑADIR FUNCIÓN") }
                Text("Las funciones nuevas deben implementarse, revisarse y aprobarse antes de ejecutar acciones. No se permite código desconocido automático.", color = Muted, fontSize = 11.sp, modifier = Modifier.fillMaxWidth().padding(top = 6.dp))
            }
        }
    }
}
@Composable private fun Status(name: String, state: String) { Row(Modifier.fillMaxWidth().padding(vertical = 3.dp), horizontalArrangement = Arrangement.SpaceBetween) { Text(name, color = Muted, fontSize = 12.sp); Text(state, color = if (state == "ACTIVE" || state == "READY" || state.endsWith("RECORDS")) Cyan else Color(0xFFFFC857), fontSize = 12.sp) } }
