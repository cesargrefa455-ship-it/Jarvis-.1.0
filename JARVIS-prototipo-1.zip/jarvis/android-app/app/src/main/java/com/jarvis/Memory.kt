package com.jarvis

import androidx.room.*

@Entity(tableName = "jarvis_memory")
data class MemoryEntity(@PrimaryKey(autoGenerate = true) val id: Long = 0, val category: String, val content: String, val createdAt: Long = System.currentTimeMillis())

@Dao
interface MemoryDao {
    @Insert suspend fun save(memory: MemoryEntity)
    @Query("SELECT * FROM jarvis_memory ORDER BY createdAt DESC") suspend fun getAll(): List<MemoryEntity>
    @Query("DELETE FROM jarvis_memory WHERE id = :id") suspend fun delete(id: Long)
}

@Database(entities = [MemoryEntity::class], version = 1, exportSchema = false)
abstract class JarvisDatabase : RoomDatabase() { abstract fun memoryDao(): MemoryDao }
