package com.jarvis

import retrofit2.http.Body
import retrofit2.http.POST
import retrofit2.Retrofit
import retrofit2.converter.moshi.MoshiConverterFactory
import com.squareup.moshi.JsonClass

@JsonClass(generateAdapter = true)
data class ChatRequest(val prompt: String, val context: String = "")
@JsonClass(generateAdapter = true)
data class ChatResponse(val response: String)

interface JarvisApi {
    @POST("ai/chat") suspend fun chat(@Body request: ChatRequest): ChatResponse
}

class RemoteAIProvider(private val api: JarvisApi) : AIProvider {
    override suspend fun generate(prompt: String, context: String): String = api.chat(ChatRequest(prompt, context)).response
}

object JarvisNetwork {
    val api: JarvisApi by lazy {
        Retrofit.Builder().baseUrl(BuildConfig.API_BASE_URL)
            .addConverterFactory(MoshiConverterFactory.create()).build().create(JarvisApi::class.java)
    }
}
