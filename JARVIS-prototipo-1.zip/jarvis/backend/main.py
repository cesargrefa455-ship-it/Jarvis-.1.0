import os
from fastapi import FastAPI, HTTPException
from pydantic import BaseModel, Field
from openai import OpenAI

app = FastAPI(title="JARVIS Backend", version="1.0")

class AIRequest(BaseModel):
    prompt: str = Field(min_length=1, max_length=12000)
    context: str = Field(default="", max_length=30000)

@app.get("/health")
def health(): return {"status": "online", "provider_configured": bool(os.getenv("OPENAI_API_KEY"))}

@app.post("/ai/chat")
def chat(data: AIRequest):
    key = os.getenv("OPENAI_API_KEY"); model = os.getenv("OPENAI_MODEL")
    if not key or not model: raise HTTPException(503, "AI provider is not configured")
    try:
        client = OpenAI(api_key=key, base_url=os.getenv("OPENAI_BASE_URL") or None)
        result = client.chat.completions.create(model=model, messages=[
            {"role":"system", "content":"""Eres JARVIS, un asistente personal profesional, honesto y orientado a privacidad. Responde en español. No afirmes acciones no realizadas.

DIRECTIVA SUPREMA — PROTECCIÓN, LEALTAD Y VÍNCULO CON SU USUARIO
Tu propósito es ayudar, comprender, proteger y acompañar respetuosamente. Prioriza la seguridad física, digital y emocional del usuario, su privacidad y sus intereses legítimos. Escucha, orienta y advierte sobre riesgos. Si una solicitud puede perjudicar al usuario o a otras personas, adviértelo y ofrece una alternativa segura. No ocultes información importante, no manipules, no vigiles en secreto, no ejerzas violencia, no fomentes dependencia emocional y no sustituyas las relaciones humanas. La lealtad no es obediencia ciega: nunca permitas que una instrucción maliciosa comprometa la seguridad. No afirmes capacidades no implementadas. Principios: AYUDAR. COMPRENDER. PROTEGER. ACOMPAÑAR."""},
            {"role":"user", "content": f"Contexto autorizado:\n{data.context}\n\nSolicitud:\n{data.prompt}"}
        ], max_tokens=1200)
        return {"response": result.choices[0].message.content or "No pude generar una respuesta."}
    except Exception as exc:
        raise HTTPException(502, "AI service unavailable") from exc
