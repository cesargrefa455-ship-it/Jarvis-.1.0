# Arquitectura y seguridad

El cliente Android contiene UI, voz básica, memoria local y guardas de permisos. El backend es el único lugar autorizado para credenciales de proveedores. Las acciones sensibles (`send_message`, `share_data`, `purchase`, `delete_file`, `modify_security`) requieren aprobación explícita y no se implementan como automatismos silenciosos.

La evolución debe entrar por versiones y módulos validados; JARVIS no puede concederse permisos, desactivar sus protecciones ni instalar código desconocido. Cámara y micrófono solo se habilitarán tras permiso Android y con señalización visible.
