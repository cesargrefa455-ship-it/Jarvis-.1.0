# Extensibilidad segura

La pantalla **Funciones y módulos** permite registrar capacidades previstas para la app y mantener visible qué está disponible. Registrar un nombre no instala ni ejecuta código: cada nueva función debe implementarse mediante una interfaz conocida, revisarse, probarse y aprobarse.

La directiva suprema se aplica tanto al proveedor remoto como al modo local. La lealtad significa proteger el bienestar, la seguridad, la privacidad y los intereses legítimos del usuario; no significa obediencia ciega ni control.
